import UIKit

let array : [(Int,String)] = [(1,"c"),(2,"d"),(3,"a"),(4,"b")]

let array1 : [(Int,String)] = array.map{(number,str) in (number * number,str)}.filter{(number,str) in return number % 2 == 0; str }.sorted(by: >) // не понял почему ругается xcode, вроде как, все ок.

print(array1) // Поменял буквы в начальном массиве местами, потому что в они и так шли по возрастанию (a,b,c,d)

